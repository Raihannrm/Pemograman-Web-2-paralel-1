<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\BukuModel;

class BukuSeeder extends Seeder
{
    public function run()
    {
        $model = new BukuModel(); //wajib membuat $model
        $model->insert([
            "judul" => "Azab",
            "penulis" => "Alghifari",
            "penerbit" => "Erlangga",
            "tahun_terbit" => "2018"
        ]);
    }
}
