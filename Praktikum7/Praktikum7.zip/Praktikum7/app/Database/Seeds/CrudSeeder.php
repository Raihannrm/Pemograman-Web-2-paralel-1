<?php

namespace App\Database\Seeds;

use App\Models\CrudModel;
use CodeIgniter\Database\Seeder;

class CrudSeeder extends Seeder
{
    public function run()
    {
        $model = new CrudModel();
        $model->insert(
            [
                "nama" => "M Raihan Maulana",
                "nim" => "2110817210016",
                "alamat" => "Banjarmasin"
            ]
            );
    }
}
