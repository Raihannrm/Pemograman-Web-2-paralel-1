<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Crud extends Migration
{
    public function up()
    {
        $field = 
        [
            "id" => [
                'type' => 'INT',
                'constraint' => 5,
                'auto_increment' => TRUE,
                'unsigned' => true
            ],
            'nama' => [
                'type' => 'VARCHAR',
                'constraint' => 50
            ],
            'nim' => [
                'type' => 'VARCHAR',
                'constraint' => 13
            ],
            'alamat' => [
                'type' => 'TEXT'
            ]
        ];
        // menambah data
        $this->forge->addField($field);
        //menjadikan primay key
        $this->forge->addKey('id', true);
        //membuat tabel
        $this->forge->createTable('crud', true);

    }

    public function down()
    {
        // menghapus
        $this->forge->dropTable('crud', true);
    }
}
