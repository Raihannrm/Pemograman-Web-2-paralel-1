<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama = "Muhammad Raihan Maulana";
    protected $nim = "2110817210016";
    protected $prodi = "Teknologi Informasi";
    protected $hobi = "Sepak Bola, Futsal dan Badminthon";
    protected $skill = "Bermain Bola";
    protected $foto = "IMG.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getHobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}